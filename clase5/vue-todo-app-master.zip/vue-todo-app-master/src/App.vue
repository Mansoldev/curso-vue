<template>
  <div>
    <Activity></Activity>
  </div>
</template>

<script>
  import Activity from "./components/Activity";
  export default {
    components: {Activity}
  }

</script>